#!/usr/bin/env python3
import math
import random
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from my_robot_interfaces.msg import Turtle, TurtleArray
from my_robot_interfaces.srv import CatchTurtle
from functools import partial
from rclpy.parameter import Parameter
from rcl_interfaces.srv import SetParameters


class TurtleControllerNode(Node):
    def __init__(self):
        super().__init__("turtle_drawing")
        self.turtle_to_catch_: Turtle = None
        self.pose_: Pose = None

        # publishers & subscribers
        self.cmd_vel_publisher_ = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.pose_subscriber_ = self.create_subscription(Pose, "/turtle1/pose", self.callback_pose, 10)
        self.alive_turtles_subscriber_ = self.create_subscription(
            TurtleArray, "alive_turtles", self.callback_alive_turtles, 10
        )

        # service clients
        self.catch_turtle_client_ = self.create_client(CatchTurtle, "catch_turtle")
        self.set_param_client_ = self.create_client(SetParameters, "/turtlesim/set_parameters")

        # control loop timer
        self.control_loop_timer_ = self.create_timer(0.01, self.control_loop)

    def callback_pose(self, pose: Pose):
        self.pose_ = pose

    def callback_alive_turtles(self, msg: TurtleArray):
        if len(msg.turtles) == 0:
            self.turtle_to_catch_ = None
            return

        # pick the closest turtle
        closest_turtle = None
        min_distance = float("inf")

        for turtle in msg.turtles:
            distance = math.sqrt((turtle.x - self.pose_.x) ** 2 + (turtle.y - self.pose_.y) ** 2)
            if distance < min_distance:
                min_distance = distance
                closest_turtle = turtle

        if closest_turtle is not None:
            self.turtle_to_catch_ = closest_turtle
            self.get_logger().info(f"Now targeting: {closest_turtle.name}")

    def control_loop(self):
        if self.pose_ is None or self.turtle_to_catch_ is None:
            return

        dist_x = self.turtle_to_catch_.x - self.pose_.x
        dist_y = self.turtle_to_catch_.y - self.pose_.y
        distance = math.sqrt(dist_x * dist_x + dist_y * dist_y)

        cmd = Twist()

        if distance > 0.5:
            # move towards turtle
            cmd.linear.x = 2.0 * distance

            # turn towards turtle
            goal_theta = math.atan2(dist_y, dist_x)
            diff = goal_theta - self.pose_.theta
            if diff > math.pi:
                diff -= 2 * math.pi
            elif diff < -math.pi:
                diff += 2 * math.pi
            cmd.angular.z = 6.0 * diff
        else:
            # reached turtle → call service
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.call_catch_turtle_service(self.turtle_to_catch_.name)

            # 🎨 change background color
            r = random.randint(0, 255)
            g = random.randint(0, 255)
            b = random.randint(0, 255)
            self.change_background(r, g, b)

            # reset so next turtle will be picked
            self.turtle_to_catch_ = None

        self.cmd_vel_publisher_.publish(cmd)

    def call_catch_turtle_service(self, turtle_name):
        while not self.catch_turtle_client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn("Waiting for catch_turtle service...")

        request = CatchTurtle.Request()
        request.name = turtle_name

        future = self.catch_turtle_client_.call_async(request)
        future.add_done_callback(partial(self.callback_catch_turtle_response, turtle_name=turtle_name))

    def callback_catch_turtle_response(self, future, turtle_name):
        response: CatchTurtle.Response = future.result()
        if response.success:
            self.get_logger().info(f"Turtle {turtle_name} was caught successfully!")
        else:
            self.get_logger().warn(f"Failed to catch turtle {turtle_name}.")

    def change_background(self, r, g, b):
        """Change turtlesim background color dynamically"""
        if not self.set_param_client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn("SetParameters service not available")
            return

        request = SetParameters.Request()
        request.parameters = [
            Parameter(name="background_r", value=r).to_parameter_msg(),
            Parameter(name="background_g", value=g).to_parameter_msg(),
            Parameter(name="background_b", value=b).to_parameter_msg(),
        ]

        future = self.set_param_client_.call_async(request)

        def callback(fut):
            if fut.result() is not None:
                self.get_logger().info(f"Background changed to RGB({r}, {g}, {b})")
            else:
                self.get_logger().warn("Failed to change background color")

        future.add_done_callback(callback)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleControllerNode()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
